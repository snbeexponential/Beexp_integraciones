/**
 * @author Angel Leon <angel.leon@beexponential.com.mx>
 * @Name ACZ_cs_geolocalizacion.js
 * @description Script para obtener y registrar la geolocalizacion de un usuario al momento de guardar un nuevo registro
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 */
define(['N/record', 'N/currentRecord', 'N/ui/dialog'], function (record, currentRecord, dialog) {
   const entry_point = {
      pageInit: null,
      saveRecord: null,
   };

   const MIN_ACCURACY = 10000;
   var count_limit = 2;
   var count = 0;

   var geodata = {
      latitude: 0,
      longitude: 0,
      accuracy: MIN_ACCURACY
   };

   entry_point.pageInit = function (context) {
      getGeolocationV2();
   }

   entry_point.saveRecord = function (context) {
      console.log('context', context);
      //var cRecord = context.currentRecord;
      if (geodata.accuracy >= MIN_ACCURACY || isGeodataEmpty()) {
         getGeolocationV2();
         showMessage('Información', 'Finalizando procesos en segundo plano. Por favor, espere unos segundos e intente de nuevo.');
         return false;
      }
      return true;
   }

   /*entry_point.saveRecord = function (context) {
      console.log('context', context);
      if (context.currentRecord.type === 'task') count_limit = 1;

      if (context.currentRecord.isNew) {
         var geoRecord = record.create({
            type: 'customrecord_acz_geolocalizacion',
            isDynamic: true
         });

         //obtenemos fecha y hora
         var today = new Date();

         geoRecord.setValue({
            fieldId: 'custrecord_acz_date',
            value: today
         });

         geoRecord.setValue({
            fieldId: 'custrecord_acz_datetime',
            value: today
         });

         //obtenemos latitud y longitud
         getGeolocation(geoRecord);
      }

      return true;
   }*/

   return entry_point;

   function getGeolocationV2() {
      var options = {
         enableHighAccuracy: true,
         timeout: 10000,
         maximumAge: 0
      };

      function success(pos) {
         var crd = pos.coords;

         console.log('Your current position is:');
         console.log('Latitude : ' + crd.latitude);
         console.log('Longitude: ' + crd.longitude);
         console.log('More or less ' + crd.accuracy + ' meters.');

         if (crd.accuracy <= MIN_ACCURACY) {
            /*var geodata = {
               latitude: crd.latitude,
               longitude: crd.longitude,
               accuracy: crd.accuracy
            };*/
            geodata.latitude = crd.latitude;
            geodata.longitude = crd.longitude;
            geodata.accuracy = crd.accuracy;
            var str_geodata = JSON.stringify(geodata);

            var cRecord = currentRecord.get();
            cRecord.setValue({ fieldId: 'custentity_acz_geo_data', value: str_geodata });
            cRecord.setValue({ fieldId: 'custevent_acz_geo_data', value: str_geodata });
            cRecord.setValue({ fieldId: 'custbody_acz_geo_data', value: str_geodata });
         }
      };

      function error(err) {
         // https://developer.mozilla.org/en-US/docs/Web/API/GeolocationPositionError/code
         console.warn('ERROR(' + err.code + '): ' + err.message);
         if (err.code == 1) {
            showMessage('Información', 'Debe permitir el acceso a su ubicación al navegador para poder registrar su firma.');
         } else {
            //showMessage('Información', 'ERROR(' + err.code + '): ' + err.message);
            console.log('ERROR(' + err.code + '): ' + err.message);
         }
      };

      navigator.geolocation.getCurrentPosition(success, error, options);
      //navigator.geolocation.watchPosition(success, error, options);
   }

   function showMessage(title, msg) {
      function success(result) { console.log('Success with value: ' + result) }
      function failure(reason) { console.log('Failure: ' + reason) }

      dialog.alert({
         title: title,
         message: msg
      }).then(success).catch(failure);
   }

   function isGeodataEmpty() {
      var cRecord = currentRecord.get();
      var entity_empty = cRecord.getValue('custentity_acz_geo_data');
      var event_empty = cRecord.getValue('custevent_acz_geo_data');
      var body_empty = cRecord.getValue('custbody_acz_geo_data');
      var not_empty = entity_empty || event_empty || body_empty;
      console.log('is_empty', !not_empty);
      return !not_empty;
   }

   async function getGeolocation(geoRecord) {
      var promise = new Promise(function (resolve) {
         var options = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
         };

         function success(pos) {
            count++;
            console.log('count', count);

            var crd = pos.coords;

            console.log('Your current position is:');
            console.log('Latitude : ' + crd.latitude);
            console.log('Longitude: ' + crd.longitude);
            console.log('More or less ' + crd.accuracy + ' meters.');

            if (count === count_limit) {
               geoRecord.setValue({
                  fieldId: 'custrecord_acz_latitude',
                  value: crd.latitude
               });

               geoRecord.setValue({
                  fieldId: 'custrecord_acz_longitude',
                  value: crd.longitude
               });

               geoRecord.save();
               resolve(true);
            }
         };

         function error(err) {
            // https://developer.mozilla.org/en-US/docs/Web/API/GeolocationPositionError/code
            console.warn('ERROR(' + err.code + '): ' + err.message);
            /*if (err.code == 1) {
               showMessage('Información', 'Debe permitir el acceso a su ubicación al navegador para poder registrar su firma.');
            } else {
               showMessage('Información', 'ERROR(' + err.code + '): ' + err.message);
            }*/
         };

         //navigator.geolocation.getCurrentPosition(success, error, options);
         navigator.geolocation.watchPosition(success, error, options);
      });
      var result = await promise;
   }
});