/**
 * @author Angel Leon <angel.leon@beexponential.com.mx>
 * @Name ACZ_ue_geolocalizacion.js
 * @description Script para registrar la geolocalizacion de un usuario al momento de guardar un nuevo registro
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/record'], function (record) {
   const entry_point = {
      afterSubmit: null,
   };

   entry_point.afterSubmit = function (context) {
      log.debug('context', context);
      let c_record = context.newRecord;

      let geodata_source = {
         from_entity: c_record.getValue('custentity_acz_geo_data'),
         from_event: c_record.getValue('custevent_acz_geo_data'),
         from_body: c_record.getValue('custbody_acz_geo_data')
      };
      log.debug('geodata_source', geodata_source);

      for (let key in geodata_source) {
         if (geodata_source[key]) {
            let geodata = JSON.parse(geodata_source[key]);

            let geoRecord = record.create({
               type: 'customrecord_acz_geolocalizacion',
               isDynamic: true
            });

            geoRecord.setValue({
               fieldId: 'custrecord_acz_latitude',
               value: geodata.latitude
            });

            geoRecord.setValue({
               fieldId: 'custrecord_acz_longitude',
               value: geodata.longitude
            });

            geoRecord.setValue({
               fieldId: 'custrecord_acz_accuracy',
               value: geodata.accuracy
            });

            geoRecord.save();
         }
      }

      //obtenemos fecha y hora
      /*var today = new Date();

      geoRecord.setValue({
         fieldId: 'custrecord_acz_date',
         value: today
      });

      geoRecord.setValue({
         fieldId: 'custrecord_acz_datetime',
         value: today
      });*/
   }

   return entry_point;
});