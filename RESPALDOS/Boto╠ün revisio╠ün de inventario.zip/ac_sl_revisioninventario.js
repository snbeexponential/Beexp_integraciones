/**
 * @author Evelyn Sarmiento Cámbara<>
 * @Modificacion <>
 * @Name ac_sl_btnInv.js
 * @description Script para mostrar boton revision de inventario 
 * @file  <URL PENDIENTE>
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/https', 'N/http', 'N/ui/serverWidget', 'N/record', 'N/search', 'N/runtime'],
    /**
     * 
     * @param {import('N/https')} https 
     * @param {import('N/ui/serverWidget')} serverWidget 
     * @param {import('N/record')} record 
     * @param {import('N/search')} search 
     */
    function (https, http, serverWidget, record, search, runtime) {

        const entry_point = {
            onRequest: null,
        };

        entry_point.onRequest = function (context) {


            switch (context.request.method) {

                case 'GET': {
                    var scriptObj = runtime.getCurrentScript(); //scriptObj is a runtime.Script object
                    log.debug('Script ID: ', scriptObj);
                    let etiqueta = context.request.parameters.etiqueta;
                    let form = serverWidget.createForm({ title: etiqueta });
                    let id = form.addField({
                        id: 'custpage_idarticulo',
                        type: serverWidget.FieldType.TEXT,
                        label: 'Ingrese el id del artículo'
                    });
                    // let ubicacion = form.addField({
                    //     id: 'custpage_ubicacion',
                    //     type: serverWidget.FieldType.TEXT,
                    //     label: 'Almacen'
                    // });
                    id.isMandatory = true;
                    var but = form.addSubmitButton({
                        id: 'buttonid',
                        label: 'Realizar Busqueda'
                    });
                    log.debug('etiqueta', etiqueta)
                    log.debug('context.request.method = ', context.request.method);
                    context.response.writePage(form);
                    break
                }

                case 'POST': {

                    let params = context.request.parameters;
                    log.debug('params', params);
                    let submitter = params['submitter'];

                    log.debug('context.request.method = POST ', context.request.method);
                    let parameters = context.request.parameters;
                    let idarticulo = parameters['custpage_idarticulo'];
                    let ubicacionloc = parameters['custpage_ubicacion'];
                    log.debug('id', idarticulo);

                    let cadena = ''
                    //if (idarticulo && ubicacionloc) {
                    //Conectamos con el servidor para obtener la información

                    const headerObj = {
                        'Content-Type': 'application/json',
                    };

                    let resp = http.get({
                        url: 'http://crm.agricenter.com.mx:5190/api/articulo/existencia/' + idarticulo,
                        headers: headerObj,

                    })
                    let json_nvo = [];
                    if (resp.code === 200) {
                        log.debug('conexion: ', 'conexion exitosa');
                        //let json_nvo = [];
                        let respoJson = JSON.parse(resp.body);
                        log.debug('resp: ', respoJson);
                        log.debug('length', typeof (respoJson.length));

                        for (x of respoJson) {
                            let id = x.Articulo;
                            let diponible = x.Disponible;
                            let ubicacion = x.Almacen;
                            json_nvo.push({
                                id: id,
                                disponible: diponible,
                                ubicacion: ubicacion
                            })
                        }

                    } else {
                        log.debug('conexion: ', 'algo salio mal')
                    }

                    log.debug('json_nvo', json_nvo);


                    // Cadena con los valores de los articulos, aun no funciona       
                    json_nvo.map(itemValues => {
                        cadena += '<tr><td>' + itemValues.id + '</td><td>' + itemValues.disponible + '</td><td>' + itemValues.ubicacion + '</td>'
                    })


                    if (idarticulo) {
                        log.debug('submit', 'testteste');

                        //Variables globales
                        var logo = 'https://5887335-sb1.app.netsuite.com/core/media/media.nl?id=11&c=5887335_SB1&h=hMXsukAZs9C-XWcISWZ8QgWKWQDewUmTPaYKxA6mAiVSf4Zp&fcts=20211028145950&whence='
                        //Variables de parametro

                        let opcion = context.request.parameters.opcion;
                        let idScripts = context.request.parameters.idScripts;
                        let urlServer = context.request.parameters.urlServer;
                        let idRecord = context.request.parameters.idRecord;

                        // Variables de estilos
                        var bodyColor = '#F7F7F7'
                        var fontRoboto = 'roboto, sans-serif'
                        var fontSaria = 'Saira Condensed, sans-serif'
                        var fontColor = '#315057'
                        var titlesColor = '#b2c447'
                        var botonColor = '#b2c447'
                        var botonFontColor = 'white'
                        var botonHoverColor = '#0B9255'
                        var botonFontHoverColor = '#FCFCFC'
                        var head = '<head>' +
                            '<meta charset="utf-8">' +
                            '<meta name="viewport" content="width=device-width, initial-scale=1">' +
                            '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"' +
                            'integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">' +
                            '<title>Inventario</title>' +
                            //'<link href="http://fonts.cdnfonts.com/css/roboto" rel="stylesheet">'+
                            '<link rel="preconnect" href="https://fonts.googleapis.com">' +
                            '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' +
                            '<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">' +
                            '<style> ' +
                            '*, html { font-family: "Saira Condensed", sans-serif; color: ' + fontColor + '; background-color: none; text-align: center; border: none;}' +
                            'html, body { background-color: ' + bodyColor + '; }' +
                            '.btn-primary {color: ' + botonFontColor + '; background-color: ' + botonColor + '; border: none;}' +
                            '.btn-primary:hover { color: ' + botonFontHoverColor + '; background-color: ' + botonHoverColor + '; }' +
                            'th {color: ' + fontColor + '; text-align: center;"}' +
                            '.fondoCabeceraOnPost { background-image:url(""); background-size:cover; background-color:white; }' +
                            '</style>' +
                            '</head>'

                        var cabecera = '<br>' +
                            '<div class="container">' +
                            '<div style="display: flex; flex-direction: row; align-items: baseline;">' +
                            '<img style=" width:150px; " src="' + logo + '" alt="MDN">' +
                            '</div>' +
                            '<div style="display: flex; flex-direction: row; align-items: baseline;">' +
                            '<h4 style="margin-left: 0px;"> Revisión de inventario </h4>' +
                            //'<p style="margin-left: 10px;"> Versión 2.0 </p>'+
                            '</div>' +
                            '</div>'




                        var html = "" +
                            '<!doctype html>' +
                            '<html lang="en">' +
                            head +
                            '<body>' +


                            '<form id="myForm" method="GET" class="form-horizontal" >' +

                            '<div class="banner">' +
                            cabecera +
                            '</div>' +
                            '<br>' +

                            '<div class="container">' +
                            '<h3 style="color: ' + titlesColor + '; font-family: Saira Condensed, sans-serif;"> I N V E N T A R I O </h3>' +
                            '<table class="table">' +
                            '<tr>' +
                            '<th>Id del artículo</th>' +
                            '<th>Número de existencias</th>' +
                            '<th>Almacén</th>' +
                            '<th></th>' +
                            '</tr>' +
                            cadena +
                            '</table>' +


                            '<button type="button" class="btn btn-primary" onClick="window.close()" style="margin-left: 10px; float: ;">  Cerrar Ventana </button>' +
                            '</div>' +

                            '<br><br><br><br>' +
                            '</form>' +

                            '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOgOMhuPIlRH9sENBO0LRn5q8nbTov41p" crossorigin="anonymous"> </script>' +


                            '</body>' +
                            '</html>'
                        context.response.setHeader({ name: 'Custom-Header-Demo', value: 'Demo' });
                        context.response.write(html);

                    }else{
                        log.debug('error','err');
                    }




                    break;

                }

            }



        };
        return entry_point;
    });