/**
 * @author Carlos Abreu<carlos.abreu@beexponential.com.mx>
 * @Name hm_rl_ARTICULOS.js
 * @description  Script para la la creación de Artículos
 * @file  <URL PENDIENTE>
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define(['N/search', 'N/record', 'N/https', 'N/format'], function (search, record, https, format) {
    const entry_point = {
        post: null,
        put: null,
        get: null
    };
    entry_point.get = function (request) {
        var id = request.id
        var objeRcord = record.load({
            type: record.Type.NON_INVENTORY_ITEM,
            id: 11,
            isDynamic: true,
        })
        var sublistName = objeRcord.getSublists();

        log.debug('sublistas', sublistName);
        log.debug('ID', id);
        log.debug('objeto', objeRcord);
        return objeRcord;



    }

    entry_point.post = function (context) {

        let request = JSON.parse(JSON.stringify(context));
        log.debug('request', request);



        let item = request.item;
        log.debug('item', item);
        let gg = request.item_total;
        log.debug('gg', gg)
        /*
        let subtotal = request.subtotal;
        log.debug('subtotal', subtotal) */
        let entityid = request.entity;
        log.debug('entityid', entityid);


        const d = new Date(request.fecha);
        log.debug('d', d);

        let SubType = request.subtype;
        log.debug('Subtipo', SubType);

        /*  const record_item = record.create({ //Se crea la sales order
             type: record.Type.INVENTORY_ITEM,
             isDynamic: true,
             defaultValues: {
                 
                
             }
         }).setValue({
             fieldId: 'subsidiary',
             value: request.subsidiary
         }).setValue({
             fieldId: 'itemid',
             value: request.itemid
         }).setValue({
             fieldId: 'subtype',
             value: SubType,
 
         }).setValue({
             fieldId: 'purchaseunit',
             value: request.purchaseunit
         }).setValue({
             fieldId: 'displayname',
             value: request.displayname
         }).setValue({
             fieldId: 'unitstype',
             value: request.unitstype
         }).setValue({
             fieldId: 'saleunit',
             value: request.saleunit
         }).setValue({
             fieldId: 'vendorname',
             value: request.vendorname
         }).setValue({
             fieldId: 'stockunit',
             value: request.stockunit
         }).setValue({ 
             fieldId: 'cogsaccount',
             value: request.cogsaccount
         }).setValue({ 
             fieldId: 'assetaccount',
             value: request.assetaccount
         }).setValue({ 
             fieldId: 'baseunit',
             value: request.baseunit
         }).setValue({ 
             fieldId: 'custitem_mx_txn_item_sat_item_code',
             value: request.custitem_mx_txn_item_sat_item_code
         }).setValue({ 
             fieldId: 'department',
             value: request.department
         }).setValue({ 
             fieldId: 'costestimatetype',
             value: request.costestimatetype
         }).setValue({ 
             fieldId: 'class',
             value: request.class
         }).setValue({ 
             fieldId: 'currency',
             value: request.currency
         }).setValue({ 
             fieldId: 'custitem_mx_txn_item_sat_item_code',
             value: request.custitem_mx_txn_item_sat_item_code
         }).setValue({ 
             fieldId: 'vendorname',
             value: request.vendorname
         })
 
         log.debug('body', record_item);
         log.debug('context', context);
         var linea;
         var precios = request.precios;
 
         precios.forEach(function (precio) {
             log.debug("PRECIO", precio)
             log.debug("PRECIO Level", precio.level)
             linea = record_item.selectLine({ sublistId: "price1", line: precio.level });
             log.debug("LA LINEA", linea)
             record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
             record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
             record_item.commitLine({ sublistId: "price1" });
         });
 
        
         record_item.save({
             ignoreMandatoryFields: true
         });
 
         var id = record_item.save({
             ignoreMandatoryFields: true
         });
 
         const response = {
             code: 200,
             message: "Artículo  inventariado agregado exitosamente",
             result: []
         };
         response.result.push({  itemid:id })
         return response;  */


        //if comentado
        if (request.type === 1) {

            const record_item = record.create({ //Se crea la sales order
                type: record.Type.NON_INVENTORY_ITEM,
                isDynamic: true,
                defaultValues: {

                }
            }).setValue({
                fieldId: 'subsidiary',
                value: request.subsidiary
            }).setValue({
                fieldId: 'itemid',
                value: request.itemid
            }).setValue({
                fieldId: 'subtype',
                value: request.subtype,

            }).setValue({
                fieldId: 'purchaseunit',
                value: request.purchaseunit
            }).setValue({
                fieldId: 'displayname',
                value: request.displayname
            }).setValue({
                fieldId: 'unitstype',
                value: request.unitstype
            }).setValue({
                fieldId: 'saleunit',
                value: request.saleunit
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'stockunit',
                value: request.stockunit
            }).setValue({
                fieldId: 'cogsaccount',
                value: request.cogsaccount
            }).setValue({
                fieldId: 'assetaccount',
                value: request.assetaccount
            }).setValue({
                fieldId: 'baseunit',
                value: request.baseunit
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'department',
                value: request.department
            }).setValue({
                fieldId: 'costestimatetype',
                value: request.costestimatetype
            }).setValue({
                fieldId: 'class',
                value: request.class
            }).setValue({
                fieldId: 'currency',
                value: request.currency
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'class',
                value: request.class
            })

            log.debug('body', record_item);
            log.debug('context', context);
            var linea;
            var precios = request.precios;

            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = record_item.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                record_item.commitLine({ sublistId: "price1" });
            });


            record_item.save({
                ignoreMandatoryFields: true
            });

            var id = record_item.save({
                ignoreMandatoryFields: true
            });

            const response = {
                code: 200,
                message: "Artículo No inventariado agregado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })
            return response;

        } if (request.type === 2) {

            const record_item = record.create({ //Se crea la sales order
                type: record.Type.INVENTORY_ITEM,
                isDynamic: true,
                defaultValues: {

                }
            }).setValue({
                fieldId: 'subsidiary',
                value: request.subsidiary
            }).setValue({
                fieldId: 'itemid',
                value: request.itemid
            }).setValue({
                fieldId: 'subtype',
                value: request.subtype,

            }).setValue({
                fieldId: 'purchaseunit',
                value: request.purchaseunit
            }).setValue({
                fieldId: 'displayname',
                value: request.displayname
            }).setValue({
                fieldId: 'unitstype',
                value: request.unitstype
            }).setValue({
                fieldId: 'saleunit',
                value: request.saleunit
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'stockunit',
                value: request.stockunit
            }).setValue({
                fieldId: 'cogsaccount',
                value: request.cogsaccount
            }).setValue({
                fieldId: 'assetaccount',
                value: request.assetaccount
            }).setValue({
                fieldId: 'baseunit',
                value: request.baseunit
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'department',
                value: request.department
            }).setValue({
                fieldId: 'costestimatetype',
                value: request.costestimatetype
            }).setValue({
                fieldId: 'class',
                value: request.class
            }).setValue({
                fieldId: 'currency',
                value: request.currency
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'class',
                value: request.class
            })

            log.debug('body', record_item);
            log.debug('context', context);
            var linea;
            var precios = request.precios;

            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = record_item.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                record_item.commitLine({ sublistId: "price1" });
            });


            record_item.save({
                ignoreMandatoryFields: true
            });

            var id = record_item.save({
                ignoreMandatoryFields: true
            });

            const response = {
                code: 200,
                message: "Artículo Inventariado agregado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })
            return response;
        } if (request.type === 3) {

            const record_item = record.create({ //Se crea la sales order
                type: record.Type.SERVICE_ITEM,
                isDynamic: true,
                defaultValues: {

                }
            }).setValue({
                fieldId: 'subsidiary',
                value: request.subsidiary
            }).setValue({
                fieldId: 'itemid',
                value: request.itemid
            }).setValue({
                fieldId: 'subtype',
                value: request.subtype,

            }).setValue({
                fieldId: 'purchaseunit',
                value: request.purchaseunit
            }).setValue({
                fieldId: 'displayname',
                value: request.displayname
            }).setValue({
                fieldId: 'unitstype',
                value: request.unitstype
            }).setValue({
                fieldId: 'saleunit',
                value: request.saleunit
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'stockunit',
                value: request.stockunit
            }).setValue({
                fieldId: 'cogsaccount',
                value: request.cogsaccount
            }).setValue({
                fieldId: 'assetaccount',
                value: request.assetaccount
            }).setValue({
                fieldId: 'baseunit',
                value: request.baseunit
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'department',
                value: request.department
            }).setValue({
                fieldId: 'costestimatetype',
                value: request.costestimatetype
            }).setValue({
                fieldId: 'class',
                value: request.class
            }).setValue({
                fieldId: 'currency',
                value: request.currency
            }).setValue({
                fieldId: 'custitem_mx_txn_item_sat_item_code',
                value: request.custitem_mx_txn_item_sat_item_code
            }).setValue({
                fieldId: 'vendorname',
                value: request.vendorname
            }).setValue({
                fieldId: 'class',
                value: request.class
            })

            log.debug('body', record_item);
            log.debug('context', context);
            var linea;
            var precios = request.precios;

            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = record_item.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                record_item.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                record_item.commitLine({ sublistId: "price1" });
            });


            record_item.save({
                ignoreMandatoryFields: true
            });

            var id = record_item.save({
                ignoreMandatoryFields: true
            });

            const response = {
                code: 200,
                message: "Servicio agregado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })
            return response;
        }
    }






    entry_point.put = function (context) {
        // Submit a new value for a sales order's memo field.
        let request = JSON.parse(JSON.stringify(context));
        let item = request.precios;

        if (request.type === 1) {
            const objRecord = record.load({ //Carga la sales order del id que le pasas por JSON
                type: record.Type.NON_INVENTORY_ITEM,
                id: request.internalid,

                isDynamic: true,
            })
                .setValue({
                    fieldId: 'subsidiary',
                    value: request.subsidiary
                }).setValue({
                    fieldId: 'itemid',
                    value: request.itemid
                }).setValue({
                    fieldId: 'subtype',
                    value: request.subtype,

                }).setValue({
                    fieldId: 'purchaseunit',
                    value: request.purchaseunit
                }).setValue({
                    fieldId: 'displayname',
                    value: request.displayname
                }).setValue({
                    fieldId: 'unitstype',
                    value: request.unitstype
                }).setValue({
                    fieldId: 'saleunit',
                    value: request.saleunit
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'stockunit',
                    value: request.stockunit
                }).setValue({
                    fieldId: 'cogsaccount',
                    value: request.cogsaccount
                }).setValue({
                    fieldId: 'assetaccount',
                    value: request.assetaccount
                }).setValue({
                    fieldId: 'baseunit',
                    value: request.baseunit
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'department',
                    value: request.department
                }).setValue({
                    fieldId: 'costestimatetype',
                    value: request.costestimatetype
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                }).setValue({
                    fieldId: 'currency',
                    value: request.currency
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                })


            log.debug('body', objRecord);




            var item_count = objRecord.getLineCount({ sublistId: 'price1' });




            var linea;
            var precios = request.precios;


            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = objRecord.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                objRecord.commitLine({ sublistId: "price1" });
            });




            var id = objRecord.save({
                ignoreMandatoryFields: true
            });



            const response = {
                code: 200,
                message: "Artículo No inventariado actualizado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })




            return response;

        } if (request.type === 2) {
            const objRecord = record.load({ //Carga la sales order del id que le pasas por JSON
                type: record.Type.INVENTORY_ITEM,
                id: request.internalid,

                isDynamic: true,
            })
                .setValue({
                    fieldId: 'subsidiary',
                    value: request.subsidiary
                }).setValue({
                    fieldId: 'itemid',
                    value: request.itemid
                }).setValue({
                    fieldId: 'subtype',
                    value: request.subtype,

                }).setValue({
                    fieldId: 'purchaseunit',
                    value: request.purchaseunit
                }).setValue({
                    fieldId: 'displayname',
                    value: request.displayname
                }).setValue({
                    fieldId: 'unitstype',
                    value: request.unitstype
                }).setValue({
                    fieldId: 'saleunit',
                    value: request.saleunit
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'stockunit',
                    value: request.stockunit
                }).setValue({
                    fieldId: 'cogsaccount',
                    value: request.cogsaccount
                }).setValue({
                    fieldId: 'assetaccount',
                    value: request.assetaccount
                }).setValue({
                    fieldId: 'baseunit',
                    value: request.baseunit
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'department',
                    value: request.department
                }).setValue({
                    fieldId: 'costestimatetype',
                    value: request.costestimatetype
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                }).setValue({
                    fieldId: 'currency',
                    value: request.currency
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                })


            log.debug('body', objRecord);




            var item_count = objRecord.getLineCount({ sublistId: 'price1' });




            var linea;
            var precios = request.precios;


            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = objRecord.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                objRecord.commitLine({ sublistId: "price1" });
            });




            var id = objRecord.save({
                ignoreMandatoryFields: true
            });



            const response = {
                code: 200,
                message: "Artículo Inventariado actualizado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })




            return response;

        } if (request.type === 3) {
            const objRecord = record.load({ //Carga la sales order del id que le pasas por JSON
                type: record.Type.SERVICE_ITEM,
                id: request.internalid,

                isDynamic: true,
            })
                .setValue({
                    fieldId: 'subsidiary',
                    value: request.subsidiary
                }).setValue({
                    fieldId: 'itemid',
                    value: request.itemid
                }).setValue({
                    fieldId: 'subtype',
                    value: request.subtype,

                }).setValue({
                    fieldId: 'purchaseunit',
                    value: request.purchaseunit
                }).setValue({
                    fieldId: 'displayname',
                    value: request.displayname
                }).setValue({
                    fieldId: 'unitstype',
                    value: request.unitstype
                }).setValue({
                    fieldId: 'saleunit',
                    value: request.saleunit
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'stockunit',
                    value: request.stockunit
                }).setValue({
                    fieldId: 'cogsaccount',
                    value: request.cogsaccount
                }).setValue({
                    fieldId: 'assetaccount',
                    value: request.assetaccount
                }).setValue({
                    fieldId: 'baseunit',
                    value: request.baseunit
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'department',
                    value: request.department
                }).setValue({
                    fieldId: 'costestimatetype',
                    value: request.costestimatetype
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                }).setValue({
                    fieldId: 'currency',
                    value: request.currency
                }).setValue({
                    fieldId: 'custitem_mx_txn_item_sat_item_code',
                    value: request.custitem_mx_txn_item_sat_item_code
                }).setValue({
                    fieldId: 'vendorname',
                    value: request.vendorname
                }).setValue({
                    fieldId: 'class',
                    value: request.class
                })


            log.debug('body', objRecord);




            var item_count = objRecord.getLineCount({ sublistId: 'price1' });




            var linea;
            var precios = request.precios;


            precios.forEach(function (precio) {
                log.debug("PRECIO", precio)
                log.debug("PRECIO Level", precio.level)
                linea = objRecord.selectLine({ sublistId: "price1", line: precio.level });
                log.debug("LA LINEA", linea)
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "currency", value: precio.currency });
                objRecord.setCurrentSublistValue({ sublistId: "price1", fieldId: "price_1_", value: precio.price });
                objRecord.commitLine({ sublistId: "price1" });
            });




            var id = objRecord.save({
                ignoreMandatoryFields: true
            });



            const response = {
                code: 200,
                message: "Servicio actualizado exitosamente",
                result: []
            };
            response.result.push({ itemid: id })




            return response;

        }
    }


    return entry_point;
});