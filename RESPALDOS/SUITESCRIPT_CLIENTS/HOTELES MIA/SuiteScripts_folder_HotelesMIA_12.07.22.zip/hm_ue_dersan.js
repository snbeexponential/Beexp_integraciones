/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
 define(['N/https', 'N/record', 'N/currentRecord',"N/ui/message"],
 /**
* @param{https} https
* @param{record} record
*/
 (https, record, currentRecord , message) => {
     /**
      * Defines the function definition that is executed before record is loaded.
      * @param {Object} scriptContext
      * @param {Record} scriptContext.newRecord - New record
      * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
      * @param {Form} scriptContext.form - Current form
      * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
      * @since 2015.2
      */
     const beforeLoad = (scriptContext) => {

        

        const response = {
            code: 200,
            message: "",
            result: []
        };
        log.debug("response", response)

        const ObjRecord = scriptContext.newRecord;

        let ID = ObjRecord.getValue({
            fieldId: 'id'
        });

        log.debug("type", ObjRecord.type)

        var objSublist = ObjRecord.getSublist({
            sublistId: 'taxdetails'
        });
        log.debug("objSublist", objSublist)

        let lines = ObjRecord.getLineCount({

            sublistId: 'taxdetails'

        });
        log.debug('lines', lines);
        
        let Renglones = [];
        


        for (let i = 0; i < lines; i++) {

            

            let itemid = ObjRecord.getSublistValue({

                sublistId: 'taxdetails',

                fieldId: 'taxtype',

                line: i

            });
            log.debug('itemid', itemid);

            let taxbasis = ObjRecord.getSublistValue({

                sublistId: 'taxdetails',

                fieldId: 'taxbasis',

                line: i

            });
            log.debug('taxbasis', taxbasis);

            let quantity = ObjRecord.getSublistValue({

                sublistId: 'item',

                fieldId: 'quantity',

                line: i

            });
            log.debug('quantity', quantity);

            let taxrate = ObjRecord.getSublistValue({

                sublistId: 'taxdetails',

                fieldId: 'taxrate',

                line: i

            });
            log.debug('taxrate', taxrate);

            let taxdetailsreference = ObjRecord.getSublistValue({

                sublistId: 'taxdetails',

                fieldId: 'taxdetailsreference',

                line: i

            });
            log.debug('taxdetailsreference', taxdetailsreference);

            let taxcode = ObjRecord.getSublistValue({

                sublistId: 'taxdetails',

                fieldId: 'taxcode',

                line: i

            });
            log.debug('taxcode', taxcode);

            Renglones.push({
                "itemid": itemid,
                "taxbasis": taxbasis,
                "quantity": quantity,
                "taxrate": taxrate,
                "taxdetailsreference": taxdetailsreference,
                "taxcode": taxcode,
                

            })


           

        

        }
        log.debug('Rengones Iteraciones', Renglones.length);
            for (let i in Renglones) {
            
                let dataSalesOrder = Renglones[i];
                log.debug('dataSalesOrder', dataSalesOrder);
            
             log.debug("i",i)

        let taxtypenumber = dataSalesOrder.itemid; 
        log.debug('taxtypenumber', taxtypenumber);


        let taxbasis = dataSalesOrder.taxbasis;
        log.debug('taxbasis', taxbasis);

       let taxdetailsreference = dataSalesOrder.taxdetailsreference;
        log.debug('taxdetailsreference', taxdetailsreference);

        let taxcode = dataSalesOrder.taxcode;
        log.debug('taxcode', taxcode);
        
        let taxrate = dataSalesOrder.taxrate;
        log.debug('taxrate', taxrate);

        let qty = dataSalesOrder.quantity;
        log.debug('Cantidad', qty);


        let uma = 96.22;
        log.debug('UMA x DIA 2022', uma);

        /* let impdersan = (uma * 0.30)*2; */
        let impdersan = ((uma * 0.30)*2)* qty;

        log.debug('Impuesto Dersan', impdersan);

        /* for (let i = 0; i < lines; i++) {} */

        
        if (taxtypenumber === "28") {

        function createPurchaseOrder() {

            
             /* rec.setValue({
                fieldId: 'entity',
                value: subsidiarypurchase
            }); */

            var rec = record.load({
                type: record.Type.INVOICE,
                id: ID,
                isDynamic: true
            });

           
          
             rec.selectNewLine({
                sublistId: 'taxdetails'
            });

            rec.setCurrentSublistValue({
                sublistId: 'taxdetails',
                fieldId: 'taxdetailsreference',
                value: taxdetailsreference,
                line: i,
                ignoreFieldChange: true,
                forceSyncSourcing: true
              });

              rec.setCurrentSublistValue({
                sublistId: 'taxdetails',
                fieldId: 'taxtype',
                value: "27",
                line: i,
                ignoreFieldChange: true,
                forceSyncSourcing: true
              });

            

            
            rec.setCurrentSublistValue({
                sublistId: 'taxdetails',
                fieldId: 'taxcode',
                value: "2402",
                line: i,
                ignoreFieldChange: true,
                forceSyncSourcing: true
              });
            
           

            rec.setCurrentSublistValue({
                sublistId: 'taxdetails',
                fieldId: 'taxbasis',
                value: taxbasis,
                line: i,
                ignoreFieldChange: true,
                forceSyncSourcing: true
              });

            rec.setCurrentSublistValue({
                sublistId: 'taxdetails',
                fieldId: 'taxrate',
                value: taxrate,
                line: i,
                ignoreFieldChange: true,
                forceSyncSourcing: true
              });
          
            rec.setCurrentSublistValue({
              sublistId: 'taxdetails',
              fieldId: 'taxamount',
              value: impdersan,
              line: i,
              ignoreFieldChange: true,
              forceSyncSourcing: true
            });
 
            
                  
             rec.commitLine({
               sublistId: 'taxdetails', 
              ignoreFieldChange: true,
              forceSyncSourcing: true
            }); 

            rec.removeLine({
                sublistId: 'taxdetails',
                line: 0,
                ignoreRecalc: true
            });
            rec.save({
                ignoreMandatoryFields: true,
                ignoreFieldChange: true,
                enableSourcing: true,
              
            });
            

           

           
          }
          
         createPurchaseOrder();
         

          


        /* var objRecord = record.load({
            type: record.Type.INVOICE,
            id: ID,
            isDynamic: true
        });

        let lines2 = objRecord.getLineCount({

            sublistId: 'taxdetails'

        });

        for (let i = 0; i < lines2; i++) {

            let taxdersan = objRecord.setSublistValue({
            sublistId: 'taxdetails',
            line: i,
            fieldId: 'taxamount',
            value: impdersan
            
        });

        let taxitem = objRecord.setSublistValue({
            sublistId: 'item',
            line: i,
            fieldId: 'taxamount',
            value: impdersan
            
        });

        log.debug('Impuesto Dersan Netsuite Record Actualizado', taxdersan);
        log.debug('Impuesto Dersan en item Netsuite actualizado', taxitem);
    } */

   /*  taxtotal
    taxtotal27 */
        
        

        /* const clienteinterco = ObjRecord.getValue({
            fieldId: "custbody1"
        })
        log.debug("Cliente Interco", clienteinterco) */


    }       
    }


     }

     /**
      * Defines the function definition that is executed before record is submitted.
      * @param {Object} scriptContext
      * @param {Record} scriptContext.newRecord - New record
      * @param {Record} scriptContext.oldRecord - Old record
      * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
      * @since 2015.2
      */
     const beforeSubmit = (scriptContext) => {
        

     }

     /**
      * Defines the function definition that is executed after record is submitted.
      * @param {Object} scriptContext
      * @param {Record} scriptContext.newRecord - New record
      * @param {Record} scriptContext.oldRecord - Old record
      * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
      * @since 2015.2
      */

     // itemreceipt= recepciones(Recepción de artículo - Item Receipt)
     // bintransfer= traslados de deposito (Traslado al depósito - Bin Transfer) 
     // transferorder= ordenes de traslados (Orden de traslado - Transfer Order)
     // ajustes (Ajuste de inventario - Inventory Adjustment)
     // devolución a proveedor(Autorización de devolución del proveedor - Vendor Return Authorization) 

     const afterSubmit = (scriptContext) => {

        
         
 }
 






     return { beforeLoad, beforeSubmit, afterSubmit }

 });